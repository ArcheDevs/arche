# Terms of Service

By visiting ("Vile") or inviting ("Vile Bot") to your Discord server, you agree and consent to the terms displayed on this page including our policies (Privacy Policy). When we state "Vile," "we," "us," and "our" in these terms, we mean Vile. "Services" mean Vile's services that we offer to users.

If any information stated here seems/is misleading, please contact us immediately at discord.gg/KsfkG3BZ4h

## Disclaimer

You may not use Vile to violate any applicable laws or regulations as well as Discord's Terms of Service and Community Guidelines. If you encounter individuals or communities doing so, please inform us in discord.gg/KsfkG3BZ4h

### You are not to do any of the following:

- Abuse or exploit Vile Bot
- Violate the Discord ToS
- Violate our terms and policies
- Copy Vile's services or features


**We reserve the right to terminate your access to our services immediately (under our sole discretion) without prior notice or liability for any reason (including, but not limited to, a breach of the terms).**

## Indemnity

You shall indemnify us against all liabilities, costs, expenses, damages and losses (including any direct, indirect or consequential losses, loss of profit, loss of reputation and all interest, penalties and legal and other reasonable professional costs and expenses) suffered or incurred by you arising out of or in connection with your use of the service, or a breach of the terms.

## Changes to the Terms of Service

We can update these terms at any time without notice. Continuing to use our services after any changes will mean that you agree with these terms and violation of our terms of service could result in a permanent ban across all of our services.
