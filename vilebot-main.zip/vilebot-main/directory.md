# Home

[Click here to invite Vile to your server](https://discord.com/api/oauth2/authorize?client_id=1002261905613799527&permissions=8&scope=bot%20applications.commands)

[Click here to join the support server](https://discord.gg/KsfkG3BZ4h)

**Vile is a free & feature-complete bot made for the best servers on Discord**

### Inviting Vile

Inviting Vile includes access to all services that Vile offers, and all services Vile may offer in the future.

[Privacy Policy](./privacy_policy.md)  •  [Terms of Service](./terms_of_service.md)
