# Embeds

Create embeds using [this](https://embeds.rival.rocks)

# Welcome & Boost Variables

> {user} - User's tag

> {user.mention} - User's mention

> {user.name} - User's name

> {user.avatar} - User's avatar

> {user.color} - Most dominant color of user's avatar

> {user.joined_at} - User's join date (timestamp)

> {user.created_at} - User's created date (timestamp)

> {user.discriminator} - User's discriminator

> {guild.name} - Server's name

> {guild.count} - Server's member count

> {guild.count.format} - Formatted server member count

> {guild.id} - Server's ID

> {guild.boost_count} - Server's boost count

> {guild.boost_tier} - Server's boost level

> {guild.booster_count} - Server's booster count

> {guild.icon} - Server's icon

# Moderation Variables

> {moderator} - Moderator's tag

> {reason} - Punishment reason

# Embed Pagination Variables

> {page.current} - Current page number

> {page.total} - Total page count

> {guild.name} - Server's name

> {guild.count} - Server's member count

> {guild.count.format} - Formatted server member count

> {guild.id} - Server's ID

> {guild.boost_count} - Server's boost count

> {guild.boost_tier} - Server's boost level

> {guild.booster_count} - Server's booster count

> {guild.icon} - Server's icon

# LastFM Variables

> {track} - Track's name

> {artist} - Artist's name

> {user} - User's tag

> {avatar} - User's avatar

> {track.url} - Track's URL

> {artist.url} - Artist's URL

> {scrobbles} - Scrobble amount

> {track.image} - Track's cover

> {lastfm.user} - User's Last.FM username

> {artist.plays} - Artist's play count

> {track.plays} - Track's play count

> {track.lower} - Track's name (lowercase)

> {artist.lower} - Artist's name (lowercase)

> {track.hyper.lower} - Track's hyperlink (lowercase)

> {artist.hyper.lower} - Artist's hyperlink (lowercase)

> {track.hyper} - Track's hyperlink

> {artist.hyper} - Artist's hyperlink

> {track.color} - Track's image color

> {artist.color} - Artist's image color
